Paul Rodriguez - 303675125
Jacqueline Lo - 203943529

Project 5

-------------

Questions:

Q1) (4)->(5)

Q2) Retrieve price stored in the secure session, which there are validity checks for (like for new session)

Q3) Used overflow-x:hidden in CSS to make sure user couldn't scroll to anything beyond the div limited to 100% width, and by preventing user from zooming in or out

Q4) By using lower percentages for width in mobile CSS depending on the device width 

-------------

user should be able to buy two items opened up in different browsers with correct results displayed.

a user can only access a buy item page if they click on the 'buy now' link, otherwise they get a friendly error

a user cannot access confirmation page using get or any other means that does not come from the buy item page.

a user can only pay for an item if they have a correct 16-digit number, otherwise the confirmation button will be disabled.

